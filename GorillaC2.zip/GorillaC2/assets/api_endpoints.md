# https://t.me/tcpsyn_bot SPACE

> All API endpoints

# Reseller and Admin Only # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
`Suggested`
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ add_user       ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &username_to_add= USERNAME_TO_ADD    &password_to_add= PASSWORD_TO_ADD &preset_to_use= PRESET_TO_USE
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ edit_user      ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_edit=    USERNAME_TO_EDIT   &field=           PASSWORD_TO_ADD &new_value=     NEW_FIELD_VALUE
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ remove_user    ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_remove=  USERNAME_TO_REMOVE
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ view_user_logs ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_view=    USERNAME_TO_SEARCH
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ view_user_plan ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_view=    USERNAME_TO_SEARCH
`Less secure and not recommended`
http:// YOUR_SERVER_IP /admin/ remove_user    ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_remove= USERNAME_TO_REMOVE
http:// YOUR_SERVER_IP /admin/ view_user_logs ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_view=   USERNAME_TO_SEARCH
http:// YOUR_SERVER_IP /admin/ view_user_plan ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_view=   USERNAME_TO_SEARCH

# Admin Only # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
`Suggested`
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ view_all_logs  ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ view_all_users ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE
`Less secure and not recommended`
http:// YOUR_SERVER_IP /admin/ remove_user    ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_remove= USERNAME_TO_REMOVE
http:// YOUR_SERVER_IP /admin/ view_user_logs ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE &user_to_view=   USERNAME_TO_SEARCH

# Super User Only # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
`Suggested`
https:// YOUR_CLOUDFLARE_DOMAIN /admin/ key_info ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE
`Less secure and not recommended`
http:// YOUR_SERVER_IP /admin/ key_info ?username= YOUR_ADMIN_USERNAME_HERE &key= YOUR_PASSWORD_HERE

# All Users # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
`Suggested`
https:// YOUR_CLOUDFLARE_DOMAIN /api/ view_ongoing ?username= YOUR_USERNAME_HERE &key= YOUR_PASSWORD_HERE
https:// YOUR_CLOUDFLARE_DOMAIN /api/ view_plan    ?username= YOUR_USERNAME_HERE &key= YOUR_PASSWORD_HERE
https:// YOUR_CLOUDFLARE_DOMAIN /api/ attack       ?username= YOUR_USERNAME_HERE &key= YOUR_PASSWORD_HERE &host={HOST}&port={PORT}&time={TIME}&method={METHOD}
*Optional for /api/attack > &concurrents=1 &rps=64 &threads=10 &geo=CN <*
`Less secure and not recommended`
http:// YOUR_SERVER_IP /api/ view_ongoing ?username= YOUR_USERNAME_HERE &key= YOUR_PASSWORD_HERE
http:// YOUR_SERVER_IP /api/ view_plan    ?username= YOUR_USERNAME_HERE &key= YOUR_PASSWORD_HERE
http:// YOUR_SERVER_IP /api/ attack       ?username= YOUR_USERNAME_HERE &key= YOUR_PASSWORD_HERE &host={HOST}&port={PORT}&time={TIME}&method={METHOD}
*Optional for /api/attack > &concurrents=1 &rps=64 &threads=10 &geo=CN <*

# More API endpoints coming soon! Join https://t.me/tcpsynack for updates!

# ADVANCED INFORMATION

https://   /admin/ add_user  ?username=  &key=  &username_to_add=  &password_to_add=  &preset_to_use=
    Response:
        {
            "error": false/true,
            "message": "Some message will be here"
        }

https://   /admin/ edit_user  ?username=  &key=  &user_to_edit=  &field_to_edit=  &new_value=
    Response:
        {
            "error": false/true,
            "message": "Some message will be here"
        }

https://   /admin/ remove_user  ?username=  &key=  &user_to_remove=
    Response:
        {
            "error": false/true,
            "message": "Some message will be here"
        }

https://   /admin/ view_user_logs ?username=  &key=  &user_to_view=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        {
	    	"error":     false,
	    	"user_logs": [{},{},{}]
	    }

https://   /admin/ view_user_plan ?username=  &key=  &user_to_view=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        {
            "error": false,
            "username":
            "password":
            "vip":
            "reseller":
            "mod":
            "admin":
            "api_access":
            "bypass_power_saving":
            "bypass_spam_protection":
            "bypass_blacklist":
            "bypass_soft_max_time":
            "telegram_id":
            "theme":
            "max_daily_attacks":
            "cooldown":
            "max_time":
            "concurrents":
            "banned":
            "locked":
            "time_redeemed":
            "formatted_time_redeemed":
            "created_by":
            "time_created":
            "formatted_time_created":
            "plan_length":
            "unix_expiry":
            "formatted_expiry":
        }

https://   /admin/ view_all_logs  ?username=  &key=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        {
            "error": false,
            "logs": [{},{},{}]
        }

https://   /admin/ view_all_users ?username=  &key=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        {
            "error": false,
            "users": [{},{},{}]
        }

https://   /admin/ key_info ?username=  &key=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        {
            "error": false,
            "screen_port":
            "license_key":
            "key_expiry":
            "build_version":
            "dlc_status":
            "developer_contact_information":
        }

https://   /api/ view_ongoing  ?username= YOUR_USERNAME_HERE &key=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        Admin/Mod:
		{
			"error":     false,
			"user_only": false,
			"ongoing":   [{},{},{}]
		}
        Non-Admin/Mod:
		{
			"error":     false,
			"user_only": true,
			"ongoing":   [{},{},{}]
		}

https://   /api/ view_plan  ?username= YOUR_USERNAME_HERE &key=
    Response:
        {
            "error": true,
            "message": "Some message will be here"
        }
        OR
        {
            "error": false,
            "username":
            "password":
            "vip":
            "reseller":
            "mod":
            "admin":
            "api_access":
            "bypass_power_saving":
            "bypass_spam_protection":
            "bypass_blacklist":
            "bypass_soft_max_time":
            "telegram_id":
            "theme":
            "max_daily_attacks":
            "cooldown":
            "max_time":
            "concurrents":
            "banned":
            "locked":
            "time_redeemed":
            "formatted_time_redeemed":
            "created_by":
            "time_created":
            "formatted_time_created":
            "plan_length":
            "unix_expiry":
            "formatted_expiry":
        }

https://   /api/ network_statistics  ?username= YOUR_USERNAME_HERE &key=

https://   /api/ attack  ?username= YOUR_USERNAME_HERE &key=  &host={HOST}&port={PORT}&time={TIME}&method={METHOD}

*Optional for /api/attack > &concurrents=1 &rps=64 &threads=10 &geo=CN <*