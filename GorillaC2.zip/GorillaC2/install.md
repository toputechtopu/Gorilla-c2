# SSN CNC Tutorial

Thank you for your trust in SSN, you will not regret it.

Current SSN version: `2.8.1`

Setup video tutorial: https://t.me/tcpsyn_bot (/ssn_client_menu)

# Suggested minimum server specs and details:

Operating System: `Ubuntu 20.04`
Ram: `1 Gb`
CPU: `1 core` @ `1 Ghz`
Storage: `3 Gb`

*Install*
chmod +x SSN
./SSN <port>